import 'package:flutter/material.dart';
import '../main.dart';

class HalamanKedua extends StatelessWidget {
  // Daftar path gambar
  final List<String> imagePaths = [
    'assets/seoul.jpg',
    'assets/busan.jpg',
    'assets/incheon.jpg',
    'assets/ulsan.jpg',
    'assets/daegu.jpg',
    'assets/seongnam.jpg',
    'assets/jeju.jpg',
    'assets/gyeongju.jpg',
    'assets/sejong.jpg',
    'assets/yongin.jpg',
  ];

  HalamanKedua({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(40.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.black, // Warna border dapat disesuaikan
                    width: 1.0, // Ketebalan border dalam pixel
                  ),
                  borderRadius: BorderRadius.circular(10.0), // Bordes sudut bulat
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Hai, Karina',
                        style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                      ),
                      CircleAvatar(
                        radius: 25, // Ukuran gambar profil
                        backgroundImage: AssetImage('assets/profile.jpg'), // Ganti dengan path gambar profil Anda
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.only(top: 40.0), // Memberikan margin atas sebesar 40.0
                child: Text(
                  'Tempat Favorit',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: 16),
              Container(
                height: 300, // Tinggi dari ListView horizontal
                child: ListView.builder(
                  scrollDirection: Axis.horizontal, // Mengatur scroll menjadi horizontal
                  itemCount: imagePaths.length, // Jumlah item sesuai dengan jumlah path gambar
                  itemBuilder: (context, index) {
                    return Container(
                      width: 250, // Lebar dari setiap item
                      margin: EdgeInsets.only(right: 16), // Jarak antara setiap item
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.0), // Bordes sudut bulat
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10.0),
                        child: Image.asset(
                          imagePaths[index], // Path gambar sesuai dengan indeks
                          fit: BoxFit.cover, // Menyesuaikan gambar ke dalam kotak
                          width: 200, // Lebar gambar
                          height: 160, // Tinggi gambar
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
