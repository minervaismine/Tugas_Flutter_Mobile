package com.example.tugas_final_mobile_flutter;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
